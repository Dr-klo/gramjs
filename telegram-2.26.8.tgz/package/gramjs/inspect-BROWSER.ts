export const inspect = {
    custom: "",
};
